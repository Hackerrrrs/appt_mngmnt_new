<footer>
				<div class="footer-inner">
					<div class="pull-left">
					<span class="text-bold text-uppercase"> Hospital Management System</span>
					</div>
					<div class="pull-right">
						<span class="go-top"><i class="ti-angle-up"></i></span>
					</div>
				</div>
			</footer>